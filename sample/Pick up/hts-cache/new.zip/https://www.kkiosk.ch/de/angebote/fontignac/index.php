<!DOCTYPE HTML>
<html lang="de">
<head>
  <meta name="GENERATOR" content="IMPERIA 10.2.2_3" />

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Fontignac | k kiosk</title>

  		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
        <meta content="index,follow" name="robots">
        <meta content="de" name="language">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <link rel="apple-touch-icon" href="/layout/img/favicons/apple-touch-icon.png">
        <link rel="shortcut icon" href="/layout/img/favicons/favicon.ico">
        <link rel="icon" type="image/png" href="/layout/img/favicons/favicon.png">
        <link rel="manifest" href="/layout/img/favicons/manifest.json">
        <link rel="mask-icon" href="/layout/img/favicons/safari-pinned-tab.svg" color="#3fc0f0">
        <meta name="msapplication-TileColor" content="#3fc0f0">
        <meta name="msapplication-TileImage" content="/layout/img/favicons/mstile.png">
		<meta name="msapplication-config" content="/layout/img/favicons/browserconfig.xml">
        <meta name="theme-color" content="#3fc0f0">  		<link rel="stylesheet" href="/layout/css/styles.css" media="all" />
		<script type="text/javascript" src="/layout/js/scripts.js" defer></script>

        <meta name="keywords" content="kiosk, kkiosk, agenturen">
        <meta name="description" content="k kiosk Gönn dir was!">

  <meta name="X-Imperia-Live-Info" content="59a420c2-7858-4c50-92aa-faf38bcc208b/2/6/237/238" />

</head>

        <body id="top" class=" de angebote fontignac">

    	<div class="loading-overlay"><div class="preloader-logo"><img alt="k kiosk" src="/layout/img/preloader.png"></div></div>
        <a class="clickblocker"></a>

        <!--[if lt IE 9]>
			<script type="text/javascript" src="/layout/js/html5shiv.js"></script>
           	<link rel="stylesheet" href="/layout/css/ie_old.css">
            <div class="infobox">
                <h1>Veralteter Browser</h1>
                <p>Sie verwenden einen veralteten Browser. Um die Webseite korrekt darzustellen und zu verwenden, aktualisieren Sie bitte Ihren Browser.</p>
                <a href="http://browsehappy.com/" target="_blank" class="button">Jetzt aktualisieren</a>
                <a class="logo" href="http://www.kkiosk.ch/"><img src="/layout/img/logo.png" alt="logo"></a>
            </div>
        <![endif]-->



                <!-- Header -->
        <header>
        	<div class="inner">
        		<div class="logo">
                	<a href="/de/"><img src="/layout/img/logo.png" alt="k kiosk"></a>
                </div>
                <nav>
                	<ul class="offernav">
                        <li class="current"><a href="/de/angebote/">Angebote</a></li>
                        <li ><a href="/de/sortiment/">Sortiment</a></li>
                        <li ><a href="/de/wettbewerbe/">Promotionen</a></li>
                        <li ><a href="/de/app/">App</a></li> 
                        <li ><a href="/de/engagement/">Engagement</a></li>                       
                        <li class="menulink">
                        	<a href="javascript:void(0);">
                        		<div class="menuicon">
                                    <span class="line"></span>
                                    <span class="line"></span>
                                    <span class="line"></span>
                                </div>
                        	</a>
                        </li>
                    </ul>
                </nav>
        	</div>
        </header>
        <!-- // Header -->

        <nav class="main-navigation">
        	<div class="nav-container">
                
<div class="nav-menu first open">
			<ul>
				<li class="top active"><a href="/">Startseite</a></li>
				<li class="angebote">
					<a href="/de/angebote/">Angebote</a></li>
				<li class="sortiment">
					<a href="/de/sortiment/">Sortiment</a></li>
				<li class="promo">
					<a href="/de/wettbewerbe/">Promotionen & Wettbewerbe</a></li>
				<li class="hasChildren app">
					<a href="/de/app/">App</a><a href="javascript:void(0);" class="more icon-right-dir" data-subnavig="app"></a></li>
				<li class="">
					<a href="/de/engagement/">Engagement</a></li>
				<li class="socialmediawand">
					<a href="/de/socialmedia/">Social Media</a></li>
				<li class="Jobs">
					<a href="/de/jobs/">Jobs</a></li>
				<li class="agenturpartner">
					<a href="/de/agenturpartner/">Agenturpartner</a></li>
				<li class="hasChildren ueberuns">
					<a href="/de/ueberuns/">Über uns</a><a href="javascript:void(0);" class="more icon-right-dir" data-subnavig="ueberuns"></a></li>
				<li class="kontakt">
					<a href="/de/allover/standortsuche/">Standorte</a></li>
				<li class="kontakt">
					<a href="/de/kontakt/">Kontakt</a></li>	</ul>
		</div>
			<div class="nav-menu second app ">
				<ul>
					<li class="top "><a href="/de/app/">App</a><a href="javascript:void(0);" class="close"><div class="closeicon"><span class="line"></span><span class="line"></span></div></a></li><li class=""><a href="/de/app/faq/">Fragen & Antworten</a></li></ul>
			</div>
			<div class="nav-menu second ueberuns ">
				<ul>
					<li class="top "><a href="/de/ueberuns/">Über uns</a><a href="javascript:void(0);" class="close"><div class="closeicon"><span class="line"></span><span class="line"></span></div></a></li><li class="ueberuns"><a href="/de/ueberuns/marke/">Marke</a></li><li class="ueberuns"><a href="/de/ueberuns/geschichte/">Geschichte</a></li></ul>
			</div>            </div>
                        <div class="nav-sidebar">
                <ul class="allover">
                    <li><a class="icon-share" href="javascript:void(0);">Teilen</a></li>
                    <li><a class="icon-search" href="/de/allover/suche/">Suche</a></li>
                    <li><a class="icon-location" href="/de/allover/standortsuche/">Standortsuche</a></li>
                    <li><a class="icon-mail-alt" href="/de/kontakt/">Kontakt</a></li>
                    <li><a class="language" href="javascript:void(0);"><span>DE</span></a></li>
                    <li><a class="country" href="/de/allover/laender/"><img alt="Schweiz" src="/layout/img/flag_ch.png"></a></li>
                </ul>
            </div>
            <div class="sharing-container">
                <div class="sharing-links">
					<a class="whatsapp" href="whatsapp://send?text=Fontignac | k kiosk" data-action="share/whatsapp/share"><i class="icon-whatsapp"></i></a>
                    <a class="facebook"><i class="icon-facebook"></i></a>
					<a class="twitter"><i class="icon-twitter"></i></a>
					<a class="googleplus"><i class="icon-gplus"></i></a>
					<a class="pinterest"><i class="icon-pinterest-circled"></i></a>
					<a class="linkedin"><i class="icon-linkedin"></i></a>
					<a class="xing"><i class="icon-xing"></i></a>
                </div>
            </div>
            <div class="languages-container">
                <ul>
                    <li><a href="/de/angebote/fontignac/index.php" class="active german">DE</a></li>                                                                            </ul>
            </div>


        </nav>


        <div class="wrapper">




    <div id="contentSlot0" class="onerow slotFullWidth greybg  teaserSlot" data-accordionID="">



	<div class="inner">


		<div class="column slotColumn1 last">

	<div class="contentTextWithImage offerdetail noSpacing">
        <div class="background-image">
            <div class="blur-image" style="background-image:url(/media/home/2017/6450-glasklar-punkten-2000x1200.png);"></div>
        </div>
		<div class="image">
			<img src="/media/home/2017/6450-glasklar-punkten-2000x1200.png" alt="Fontignac" />
		</div>
        <div class="text">
                <h3 class="sectionTitle">Auf deinen Tisch - kristallklare Gläser</h3>
			<p><strong>Einzigartig - jetzt in unserer grossen Sammelpromotion</strong></p>

<p>Profitiere von diesem exklusiven Vorteilsrabatt. Bis zu 82% Rabatt mit einem vollen Treueheft. Bis zum 24. September l&auml;uft die Sammelpromotion mit den wunderbaren Glaswaren der Marke Fontignac.</p>

<p><a class="button" href="#maincontent">Mehr erfahren</a></p>

		</div>
        <div class="clearer"></div>
	</div>

	</div>

	</div>

</div>


    <div id="contentSlot2" class="onerow slotThreeColumns noStyle noWidths  noMargin" data-accordionID="">



	<div class="inner">


		<div class="column slotColumn1">


	<div class="contentTitle standardSpacing">
		<h2> Traditionsmarke Fontignac</h2>
	</div>

	<div class="contentImage noStyle standardSpacing">
		<div class="image">
			<a href="http://www.fontignacpromotion.ch" target="_blank">
                <img src="/media/angebote/fontignac/rotweinglas_gefüllt.jpg" alt="" />
			</a>
		</div>
	</div>

	<div class="contentText framed standardSpacing">
		<div class="text">
			<p><strong>Weitere Fragen?</strong> Alle Informationen inklusive FAQ findest du hier: <a href="http://www.fontignacpromotion.ch" target="_blank">www.fontignacpromotion.ch</a></p>

		</div>
	</div>

		</div>

		<div class="column slotColumn2">

	<div class="contentTitle standardSpacing">
		<h2>Deine Gläsersammlung</h2>
	</div>

	<div class="contentText noStyle noSpacing">
		<div class="text">
			<p><strong>Mit unseren Treuepunkten verzauberst du deinen Tisch mit Gl&auml;sern der franz&ouml;sischen Marke Fontignac:</strong></p>

<ul>
	<li>Hochw&auml;rtiges, kristallklares Glas</li>
	<li>Gezogener Stiel<br />
	(Kelch und Stiel sind ein St&uuml;ck)</li>
	<li>D&uuml;nner, feiner Rand</li>
	<li>Extremer Glanz</li>
	<li>Hergestellt in Deutschland</li>
</ul>

<p><strong>Schau dir auf unserer <a href="http://www.fontignacpromotion.ch" target="_blank">Promotions-Website</a> alle unsere zu sammelnden Produkte an.&nbsp;</strong></p>

<p>Die Fontignac-Gl&auml;ser sind eine moderne Interpretation des klassischen Glases. Die Produkte wurden strengsten Tests unterzogen. So gew&auml;hrleisten sie stets zuverl&auml;ssige Funktionalit&auml;t. Jedes Produkt ist in Bezug auf Details und Optik einzigartig.</p>

<ul>
	<li>Rotweinglas</li>
	<li>Longdrinkglas</li>
	<li>Wasser- / Whiskyglas</li>
	<li>Weissweinglas</li>
	<li>Lik&ouml;rglas</li>
	<li>Schale</li>
	<li>Sektglas</li>
</ul>

		</div>
	</div>


		</div>

		<div class="column slotColumn3 last">

	<div class="contentTitle standardSpacing">
		<h2>So funktioniert's</h2>
	</div>

	<div class="contentText noStyle standardSpacing">
		<div class="text">
			<p><strong>Vom 26.06.2017 bis und mit 24.09.2017</strong></p>

<p>Pro 5.- CHF Einkaufswert gibt es jeweils eine Treuemarke. Dies bei jedem Einkauf bei uns, <a href="http://pressbooks.ch" target="_blank">Press &amp; Books</a> oder <a href="http://avec.ch" target="_blank">avec</a> (Schweiz).</p>

<p>Sammle die Marken im Treueheft. Gegen Abgabe des vollen Treueheftes (20 Treuemarken) bei deiner Verkaufsstelle erh&auml;ltst du eines der abgebildeten Produkte der Marke Fontignac mit exklusivem Vorteilsrabatt von bis 82%. Einl&ouml;sbar bis 24.09.2017 (solange Vorrat).</p>

		</div>
	</div>

	<div class="contentImage teaser noSpacing">
		<div class="image">
                <img src="/media/angebote/fontignac/fontignac_treueheft.jpg" alt="" />
		</div>
	</div>


		</div>
		<div class="clearer"></div>

	</div>

</div>


    <div id="contentSlot3" class="onerow slotFiveColumns greybg noWidths  noMargin" data-accordionID="">



	<div class="inner">


		<div class="column slotColumn1">

	<div class="contentImage teaser noSpacing">
		<div class="image">
			<a href="http://www.fontignacpromotion.ch" target="_blank">
                <img src="/media/angebote/fontignac/fontignac_longdrinkglas.jpg" alt="Fontignac Whiskyglas" />
			</a>
		</div>
	</div>

		</div>

		<div class="column slotColumn2 midbreak">

	<div class="contentImage teaser noSpacing">
		<div class="image">
			<a href="http://www.fontignacpromotion.ch" target="_blank">
                <img src="/media/angebote/fontignac/fontignac_whisky-wasserglas.jpg" alt="Fontignac Weissweinglas" />
			</a>
		</div>
	</div>

		</div>

		<div class="column slotColumn3">

	<div class="contentImage teaser noSpacing">
		<div class="image">
			<a href="http://www.fontignacpromotion.ch" target="_blank">
                <img src="/media/angebote/fontignac/fontignac_weissweinglas.jpg" alt="Fontignac Rotweinglas" />
			</a>
		</div>
	</div>

		</div>

		<div class="column slotColumn4">

	<div class="contentImage teaser noSpacing">
		<div class="image">
			<a href="http://www.fontignacpromotion.ch" target="_blank">
                <img src="/media/angebote/fontignac/fontignac_likoerglas.jpg" alt="Fontignac Sektglas" />
			</a>
		</div>
	</div>

		</div>

		<div class="column slotColumn5 last">

	<div class="contentImage teaser noSpacing">
		<div class="image">
			<a href="http://www.fontignacpromotion.ch" target="_blank">
                <img src="/media/angebote/fontignac/fontignac_schale.jpg" alt="fontignac Likoerglas" />
			</a>
		</div>
	</div>

		</div>
		<div class="clearer"></div>

	</div>

</div>


    <div id="contentSlot4" class="onerow slotTwoColumns noStyle size7525  noMargin" data-accordionID="">



	<div class="inner">


		<div class="column slotColumn1">

	<div class="contentTitle standardSpacing">
		<h2>Fontignac - Lust auf's Anstossen.</h2>
	</div>

	<div class="contentText noStyle standardSpacing">
		<div class="text">
			<p>Bei dieser traditionsreichen, franz&ouml;sischen Marke steht nat&uuml;rliches, gesundes Kochen im Mittelpunkt. Im Laufe der Jahre hat sich Fontignac in der Koch- und Esskultur Frankreichs einen Namen gemacht. Die Unternehmensgeschichte ist in der Herstellung von Gusseisen verankert. Die Marke ist stolz auf ihre Wurzeln. Bei der Entwicklung s&auml;mtlicher Produkte von Fontignac wird Tradition in Ehren gehalten. Jahrzehntelang war Fontignac eine Handelsmarke der franz&ouml;sischen Staub-Gruppe. Fontignac is a trademark of the Staub Group used under license by Brand Loyalty Sourcing BV.</p>

<p>Fontignac ist der gastronomischen Tradition Frankreichs treu geblieben. Qualit&auml;t und Know-how haben Fontignac zu DER K&uuml;chenmarke f&uuml;r jeden Tag gemacht.</p>

<p>Die Gl&auml;ser von Fontignac sind eine moderne Interpretation des klassischen Glases. Das umfangreiche Sortiment bietet Gl&auml;ser f&uuml;r jeden Anlass. Dein Produkt wurde strengsten Tests unterzogen. So gew&auml;hrleistet Fontignac stets zuverl&auml;ssige Funktionalit&auml;t. Jedes Produkt ist in Bezug auf Details und Optik einzigartig.</p>

<p>Entdecken Sie, was Fontignac dir alles zu bieten hat. Freue dich auf praktische, benutzerfreundliche und pflegeleichte Gl&auml;ser!</p>

<p><a class="button" href="http://www.fontignaccollection.com/de-DE/" target="_blank">Fontignac Webseite</a></p>

		</div>
	</div>

		</div>

		<div class="column slotColumn2 last">

	<div class="contentImage noStyle standardSpacing">
		<div class="image">
			<a href="http://fontignacpromotion.ch/" target="_blank">
                <img src="/media/angebote/fontignac/sektglas_gefüllt.jpg" alt="fontignac k kiosk" />
			</a>
		</div>
	</div>

		</div>
		<div class="clearer"></div>

	</div>

</div>


    <div id="contentSlot5" class="onerow slotFourColumns greybg noWidths  noMargin" data-accordionID="">



	<div class="inner">


		<div class="column slotColumn1">

	<div class="contentText noStyle standardSpacing">
		<h3 class="sectionTitle"> Treueheft</h3>
		<div class="text">
			<p>Pro CHF 5.- Einkauf gab&#39;s einen Treuepunkt. Treuehefte gibt&#39;s in jeder Filiale. Volle Treuehefte k&ouml;nnen bis am 24.09.2017 eingel&ouml;st werden. Es ist keine Barauszahlung m&ouml;glich. Nur solange der Vorrat reicht.</p>

		</div>
	</div>

		</div>

		<div class="column slotColumn2 midbreak">

	<div class="contentText noStyle standardSpacing">
		<h3 class="sectionTitle">Informationen</h3>
		<div class="text">
			<p>Alle Infos zu unserer Promotion.</p>

<p><a class="button" href="http://www.fontignacpromotion.ch/" target="_blank">Mehr erfahren</a></p>

		</div>
	</div>

		</div>

		<div class="column slotColumn3">

	<div class="contentText noStyle standardSpacing">
		<h3 class="sectionTitle">Fontignac erleben</h3>
		<div class="text">
			<p>Lust auf Kochen - Erlebe die Marke Fontignac</p>

<p><a class="button" href="http://www.fontignaccollection.com/de-DE/home/" target="_blank">Fontignac</a></p>

		</div>
	</div>

		</div>

		<div class="column slotColumn4 last">

	<div class="contentTitle standardSpacing">
		<h3>Downloads</h3>
	</div>

	<div class="contentDownload noStyle  standardSpacing">

		<div class="downloadMainEntry">
			<a href="/media/angebote/fontignac/fontignac_teilnahmebedingungen.pdf" class="pdf">
				<div class="downloadFileName"> So geht's & Teilnahmebedingungen</div>
				<div class="downloadDescription"></div>
				<div class="downloadFilesize">pdf, 6.1 MB</div>
                <div class="clearer"></div>
			</a>
		</div>

		<div class="downloadEnd"></div>
	</div>


		</div>
		<div class="clearer"></div>

	</div>

</div>


            <div class="push"></div>
        </div>

                    <footer class="stickyfooter">
            <div class="footer">
                <div class="inner">
                    <div class="address">
                        <a href="/de/" class="footerlogo"><img src="/layout/img/logo_footer.png" alt="k kiosk"></a>
                        <p>
                            <strong>Valora Schweiz AG</strong><br>
                            Hofackerstrasse 40<br>
                            CH-4132 Muttenz
                        </p>
                    </div>
                    <div class="sitemap">
                        <ul>
                            <li>
                                <a href="/de/angebote/">Angebote</a>
                                <a href="/de/sortiment/">Sortiment</a>
                                <a href="/de/wettbewerbe/">Wettbewerbe</a>
                            </li>
                            <li>
                                <a href="/de/agenturpartner/">Agenturpartner</a>
                                <!--<ul>
                                    <li><a href="/de/agenturpartner/vorteile/">Vorteile</a></li>
                                    <li><a href="/de/agenturpartner/voraussetzungen/">Voraussetzungen</a></li>
                                    <li><a href="/de/agenturpartner/bewerbung/">Bewerbung</a></li>
                                    <li><a href="/de/agenturpartner/faq/">FAQ</a></li>
                                </ul> -->
                            </li>
                            <li>
                                <a href="/de/ueberuns/">Über uns</a>
                                <ul>
                                    <li><a href="/de/ueberuns/marke/">Marke</a></li>
                                    <li><a href="/de/ueberuns/geschichte/">Geschichte</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="/de/socialmedia/">Social Media</a>
                                <a href="/de/jobs/">Jobs</a>
                                <a href="/de/allover/standortsuche/">Standorte</a>
                                <a href="/de/kontakt/">Kontakt</a>
                            </li>
                        </ul>
                    </div>
                    <div class="socialmedia">
                        <strong>Social Media</strong>
                        <a href="https://www.facebook.com/kkiosk" target="_blank" class="button facebook"><i class="icon-facebook"></i><span>Facebook</span></a>
                        <a href="https://www.instagram.com/k_kiosk/" target="_blank" class="button instagramm"><i class="icon-instagramm"></i><span>Instagram</span></a>
                        <a href="https://twitter.com/kkiosk" target="_blank" class="button twitter"><i class="icon-twitter"></i><span>Twitter</span></a>
                        <a href="https://www.youtube.com/user/my1kkiosk" target="_blank" class="button youtube"><i class="icon-youtube-play"></i><span>YouTube</span></a>
                        <a href="https://www.flickr.com/photos/valora/sets/72157631588342247/" target="_blank" class="button flickr"><i class="icon-flickr-1"></i><span>Flickr</span></a>
                        <p class="brandof">eine Marke von<br><a href="http://www.valora.com/" target="_blank"><img src="/layout/img/logo_footer_valora.png" alt="valora"></a></p>                            
                    </div>
                    <div class="clearfix"></div>                        
                    <div class="copyright">
                        <p>2017 &copy; Valora Schweiz AG</p>
                    </div>                        
                    <div class="imprint">
                        <!-- <p><a href="/de/allover/impressum/#terms">Nutzungsbedingungen</a> --><p><a href="/de/allover/impressum/#privacy">Datenschutz</a><a href="/de/allover/impressum/#imprint">Impressum</a></p>
                    </div>        
                    <div class="clearfix"></div>
                </div>
            </div>
        </footer>


            <!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(["setCookieDomain", "*.kkiosk.ch"]);
  _paq.push(["setDomains", ["*.kkiosk.ch","*.kkiosk.com"]]);
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//piwik.valora.com/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', 7]);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//piwik.valora.com/piwik.php?idsite=7" style="border:0;" alt="" /></p></noscript>
<!-- End Piwik Code -->
    </body>
</html>
